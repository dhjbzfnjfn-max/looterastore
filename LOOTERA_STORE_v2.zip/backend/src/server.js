import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import crypto from "crypto";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const products = [
  { id: "ps5-game", category: "PlayStation 5", title: "Игра для PlayStation 5", price: 0, note: "Цена уточняется перед оплатой" },
  { id: "steam-game", category: "PC / Steam", title: "Игра Steam", price: 0, note: "Цена уточняется перед оплатой" },
  { id: "epic-game", category: "PC / Epic Games", title: "Игра Epic Games", price: 0, note: "Цена уточняется перед оплатой" },
  { id: "mobile-app", category: "Мобильные приложения", title: "Покупка приложения / подписки", price: 0, note: "Цена уточняется перед оплатой" },
  { id: "mobile-game", category: "Мобильные игры", title: "Донат / игровая валюта / Battle Pass", price: 0, note: "Цена уточняется перед оплатой" }
];

const orders = [];

app.get("/api/products", (_req, res) => {
  res.json(products);
});

app.post("/api/orders", (req, res) => {
  const { telegramUser, product, accountData, paymentMethod } = req.body;

  if (!product || !accountData || !paymentMethod) {
    return res.status(400).json({ error: "Заполнены не все поля" });
  }

  const order = {
    id: crypto.randomUUID(),
    createdAt: new Date().toISOString(),
    status: "awaiting_payment",
    telegramUser: telegramUser || null,
    product,
    accountData,
    paymentMethod
  };

  orders.push(order);

  // В production здесь будет:
  // 1) создание платежа ЮKassa;
  // 2) безопасное шифрование accountData;
  // 3) уведомление администратора в Telegram;
  // 4) автоматическое удаление accountData после выполнения заказа.

  res.status(201).json({
    orderId: order.id,
    status: order.status,
    message: "Заказ создан"
  });
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "LOOTERA STORE" });
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`LOOTERA STORE backend listening on port ${port}`);
});
