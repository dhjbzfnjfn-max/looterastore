const API = window.LOOTERA_API || "http://localhost:3000/api";

const categories = [
  "PlayStation 5",
  "PC / Steam",
  "PC / Epic Games",
  "Мобильные приложения",
  "Мобильные игры"
];

let products = [];
let selectedProduct = null;

const $ = (id) => document.getElementById(id);

function renderCategories() {
  $("categories").innerHTML = categories.map(c =>
    `<div class="tile" onclick="showCategory('${c.replaceAll("'", "\'")}')">
      <strong>${c}</strong><span>Открыть каталог →</span>
    </div>`
  ).join("");
}

async function loadProducts() {
  try {
    const r = await fetch(`${API}/products`);
    products = await r.json();
  } catch {
    products = categories.map((c, i) => ({
      id: String(i), category: c, title: c, price: 0, note: "Цена уточняется"
    }));
  }
}

window.showCategory = function(category) {
  const list = products.filter(p => p.category === category);
  $("catalogSection").hidden = false;
  $("catalogTitle").textContent = category;
  $("products").innerHTML = list.map(p =>
    `<div class="tile" onclick="selectProduct('${p.id}')">
      <strong>${p.title}</strong>
      <span>${p.note || ""}</span>
      <div class="price">${p.price ? p.price + " ₽" : "Цена уточняется"}</div>
    </div>`
  ).join("") || `<div class="card">Товаров пока нет.</div>`;
  $("catalogSection").scrollIntoView({behavior:"smooth"});
};

window.selectProduct = function(id) {
  selectedProduct = products.find(p => p.id === id);
  $("selectedProduct").innerHTML =
    `<div class="card"><strong>${selectedProduct.title}</strong><div>${selectedProduct.category}</div></div>`;
  $("orderSection").hidden = false;
  $("orderSection").scrollIntoView({behavior:"smooth"});
};

$("orderButton").onclick = async () => {
  if (!selectedProduct) return;
  const accountData = $("accountData").value.trim();
  const paymentMethod = $("paymentMethod").value;
  if (!accountData) {
    $("result").textContent = "Введите данные аккаунта.";
    return;
  }

  $("result").textContent = "Создаём заказ…";

  const payload = {
    telegramUser: window.Telegram?.WebApp?.initDataUnsafe?.user || null,
    product: selectedProduct,
    accountData,
    paymentMethod
  };

  try {
    const r = await fetch(`${API}/orders`, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(payload)
    });
    const data = await r.json();
    $("result").textContent = r.ok
      ? `Заказ создан: ${data.orderId}`
      : (data.error || "Ошибка");
  } catch {
    $("result").textContent = "Не удалось связаться с сервером.";
  }
};

renderCategories();
loadProducts();
