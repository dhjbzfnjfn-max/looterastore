# LOOTERA STORE

Telegram Mini App + backend starter for a digital-goods store.

## Structure
- `backend/` — Node.js API
- `miniapp/` — Telegram Mini App frontend
- `.env.example` — environment variables template

## Important
Never commit a real Telegram bot token, payment secret, or customer account credentials to GitHub.
